package com.example.yourapp.entities;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Portfolio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "client_id")
    private Client client;

    private String createdAt;

    @OneToMany(mappedBy = "portfolio", cascade = CascadeType.ALL)
    private Set<Security> securities;

    public Portfolio() {}

    public Portfolio(Client client, String createdAt) {
        this.client = client;
        this.createdAt = createdAt;
    }

    public Long getId() { return id; }

    public Client getClient() { return client; }
    public void setClient(Client client) { this.client = client; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }

    public Set<Security> getSecurities() { return securities; }
    public void setSecurities(Set<Security> securities) { this.securities = securities; }
}
